<?php require_once('inc/header.inc.php'); ?>
<?php if (userConnect()) : ?>
		<div><a href="index.php?op=new">Ajouter un nouvel employe</a></div>
<?php endif; ?>

<section id="services">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 text-center">
				<h2 class="section-heading">At Your Service</h2>
				<hr class="primary">
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<?php foreach($competences as $c) :  ?>
			<div class="col-lg-3 col-md-6 text-center">
				<div class="service-box">
					<img src="<?php echo $c->logo; ?>" alt="" width="250">
					<h3><?php echo htmlentities($c->code);  ?></h3>
					<p class="text-muted"<?php echo htmlentities($c->details); ?>.</p>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<!-- <a href="index.php?op=show&id=<?php echo $c->id_competence; ?>"></a>
<a href="index.php?op=delete&id=<?php echo $c->id_competence; ?>"></a>
<a href="index.php?op=update&id=<?php echo $c->id_competence; ?>"></a> -->
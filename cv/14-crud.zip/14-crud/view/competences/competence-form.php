<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo htmlentities($title); ?></title>
	<link rel="stylesheet" type="text/css" href="view/css/style.css">
</head>
<body>
	<form method="POST" action="">
		<label for="code">Prenom :</label><br>
		<input type="text" name="code" id="code" value="<?= $code ?>"><br>

		<label for="details">Nom :</label><br>
		<input type="text" name="details" id="details" value="<?= $details ?>"><br>

		<label for="logo">Nom :</label><br>
		<input type="text" name="logo" id="logo" value="<?= $logo ?>"><br>

		<input type="submit" value="Ajouter">
	</form>
</body>
</html>
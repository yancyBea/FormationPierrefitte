<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo $competence->code; ?></title>
	<link rel="stylesheet" type="text/css" href="view/css/style.css">
</head>
<body>
	<h1><?php echo $competence->code; ?></h1>

	<div>
		<span>Prenom :</span>
		<?php echo $competence->details; ?>
	</div>
	
</body>
</html>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo $experience->entreprise; ?></title>
	<link rel="stylesheet" type="text/css" href="view/css/style.css">
</head>
<body>
	<h1><?php echo $experience->entreprise; ?></h1>

	<div>
		<span>Prenom :</span>
		<?php echo $experience->date; ?>
	</div>

</body>
</html>
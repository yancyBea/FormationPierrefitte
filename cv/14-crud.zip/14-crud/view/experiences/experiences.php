<section class="bg-primary" id="about">
	<div class="container-fluid">
		<div class="row no-gutter popup-gallery">
			<?php foreach($experiences as $e) :  ?>
			<div class="col-lg-6 col-sm-6">
				<a href="#" class="portfolio-box">
					<img src="<?php echo URL; ?>public/img/portfolio/thumbnails/1.jpg" class="img-responsive" alt="">
					<div class="portfolio-box-caption">
						<div class="portfolio-box-caption-content">
							<div class="project-category text-faded">
								<?php echo htmlentities($e->poste); ?><br>
								<?php echo htmlentities($e->date); ?>
							</div>
							<div class="project-name">
								<?php echo htmlentities($e->entreprise);  ?>
							</div>
						</div>
					</div>
				</a>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo htmlentities($title); ?></title>
	<link rel="stylesheet" type="text/css" href="view/css/style.css">
</head>
<body>
	<form method="POST" action="">
		<label for="entreprise">Prenom :</label><br>
		<input type="text" name="entreprise" id="entreprise" value="<?= $entreprise ?>"><br>

		<label for="poste">Nom :</label><br>
		<input type="text" name="poste" id="poste" value="<?= $poste ?>"><br>

		<label for="date">Nom :</label><br>
		<input type="text" name="date" id="date" value="<?= $date ?>"><br>

		<label for="tache">Nom :</label><br>
		<input type="text" name="tache" id="tache" value="<?= $tache ?>"><br>

		<input type="submit" value="Ajouter">
	</form>
</body>
</html>
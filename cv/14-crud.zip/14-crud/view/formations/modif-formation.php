<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Update</title>
	<link rel="stylesheet" type="text/css" href="view/css/style.css">
</head>
<body>
	<form method="POST" action="">
		<label for="nomFormation">Prenom :</label><br>
		<input type="text" name="nomFormation" id="nomFormation" value="<?= $formation->nomFormation ?>"><br>

		<label for="dateDebut">Nom :</label><br>
		<input type="date" name="dateDebut" id="dateDebut" value="<?= $formation->dateDebut ?>"><br>

		<label for="dateFin">Nom :</label><br>
		<input type="date" name="dateFin" id="dateFin" value="<?= $formation->dateFin ?>"><br>

		<label for="description">Nom :</label><br>
		<input type="text" name="description" id="description" value="<?= $formation->description ?>"><br>

		<input type="submit" value="Ajouter">
	</form>
</body>
</html>
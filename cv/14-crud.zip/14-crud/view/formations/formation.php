<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title><?php echo $formation->nomFormation; ?></title>
	<link rel="stylesheet" type="text/css" href="view/css/style.css">
</head>
<body>
	<h1><?php echo $formation->description; ?></h1>

</body>
</html>
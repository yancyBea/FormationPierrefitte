<section id="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
					<ul class="timeline">
						<?php foreach ($formations as $f) {
							$id = $f->id_formation;

							if (($id % 2) == 0) {
						?>
						<li>
							<div class="timeline-badge"><i class="glyphicon glyphicon-check"></i></div>
							<div class="timeline-panel">
								<div class="timeline-heading">
								<h4 class="timeline-title"><?php echo htmlentities($f->nomFormation);  ?></h4>
								<p><small class="text-muted"><i class="glyphicon glyphicon-time"></i> <?php echo htmlentities($f->dateDebut);  ?></small></p>
								</div>
								<div class="timeline-body">
								<p>Mussum ipsum cacilds, vidis litro abertis. Consetis adipiscings elitis. Pra lá , depois divoltis porris, paradis. Paisis, filhis, espiritis santis. Mé faiz elementum girarzis, nisi eros vermeio, in elementis mé pra quem é amistosis quis leo. Manduma pindureta quium dia nois paga. Sapien in monti palavris qui num significa nadis i pareci latim. Interessantiss quisso pudia ce receita de bolis, mais bolis eu num gostis.</p>
								</div>
							</div>
						</li>
						<?php } else { ?>
						<li class="timeline-inverted">
							<div class="timeline-badge warning"><i class="glyphicon glyphicon-credit-card"></i></div>
							<div class="timeline-panel">
								<div class="timeline-heading">
								<h4 class="timeline-title"><?php echo htmlentities($f->nomFormation);  ?></h4>
								</div>
								<div class="timeline-body">
								<p><?php echo $f->description; ?></p>
								</div>
							</div>
						</li>
						<?php } }?>
					</ul>
                </div>
            </div>
        </div>
	</div>
</section>

<?php require_once('inc/footer.inc.php'); ?>
<?php

namespace controller;

class FormationController{

	private $db;
	public function __construct(){

		$e = new Error; //gestion des erreurs. Pas besoin d'ecrire: controller\Error car le fichier se trouve déjà à l'intérieur

		$this->db = new \model\FormationEntityRepository;

	}
	//-------------------------------------------------
	public function redirect($location){

		header('Location: ' . $location);
	}

	//-------------------------------------------------
	public function handleRequest(){

		$fo = isset( $_GET['fo'] ) ? $_GET['fo'] : NULL;

		try{
			if( !$fo || $fo == 'list'){
				$this->listFormations();
			}
			elseif( $fo == 'new' ){
				$this->saveFormation();
			}
			elseif( $fo == 'delete' ){
				$this->deleteFormation();
			}
			elseif( $fo == 'show'){
				$this->showFormation();
			}

			//-------------------------------------------------
			// COORECTION 
			//-------------------------------------------------
			elseif( $fo == 'update'){				
				$this->updateFormation();
			}
			else{
				$this->showError("Page not found", "Page for operation ". $fo ." was not found." );
			}
		}
		catch(Exception $e){

			$this->showError("Application error", $e->getMessage() );
		}
	}
	//-------------------------------------------------
	public function listFormations(){

		$orderby = isset($_GET['orderby']) ? $_GET['orderby'] : NULL;

		$formations = $this->db->selectAll($orderby);

		include 'view/formations/formations.php';
	}
	//-------------------------------------------------
	public function saveFormation(){

		$title = 'Add new formation';

		$nomFormation ='';
		$dateDebut ='';
		$dateFin = '';
		$description = '';


		if( $_POST) {

			$code = isset($_POST['nomFormation']) ? $_POST['nomFormation'] : NULL;
			$dateDebut = isset($_POST['dateDebut']) ? $_POST['dateDebut'] : NULL;
			$dateFin = isset($_POST['dateFin']) ? $_POST['dateFin'] : NULL;
			$description = isset($_POST['description']) ? $_POST['description'] : NULL;
			
			try{

				$res = $this->db->insert();
				$this->redirect('index.php');
				return;
			}
			catch(Exception $e){
				echo 'erreur !!';
			}
		}
		include 'view/formations/formation-form.php';
	}

	//-------------------------------------------------
	public function deleteFormation(){

		$id = isset($_GET['id']) ? $_GET['id'] : NULL;

		if( !$id ){

			throw new Exception('Internal error.');
		}
		$res = $this->db->delete($id);

		$this->redirect('index.php');
	}

	//-------------------------------------------------
	public function showFormation(){

		$id = isset($_GET['id']) ? $_GET['id'] : NULL;

		if( ! $id ){

			throw new Exception('Internal error.');
		}
		$formation = $this->db->select($id);

		include 'view/formations/formation.php';
	}

	//-------------------------------------------------
	// COORECTION 
	//-------------------------------------------------
	public function updateFormation(){

		$id = isset($_GET['id']) ? $_GET['id'] : NULL;
		if( ! $id ){
			throw new Exception('Internal error.');
		}
		$formation = $this->db->select($id);

		$nomFormation ='';
		$dateDebut ='';
		$dateFin = '';
		$description = '';


		if( $_POST) {

			$code = isset($_POST['nomFormation']) ? $_POST['nomFormation'] : NULL;
			$dateDebut = isset($_POST['dateDebut']) ? $_POST['dateDebut'] : NULL;
			$dateFin = isset($_POST['dateFin']) ? $_POST['dateFin'] : NULL;
			$description = isset($_POST['description']) ? $_POST['description'] : NULL;
			
			try{

				$res = $this->db->update($id);
				$this->redirect('index.php');
			}
			catch(Exception $e){
				echo 'erreur !!';
			}
		}
		include 'view/formations/modif-formation.php';
	}
}
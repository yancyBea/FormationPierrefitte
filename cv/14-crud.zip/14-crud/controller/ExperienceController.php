<?php

namespace controller;

class ExperienceController{

	private $db;
	public function __construct(){

		$e = new Error; //gestion des erreurs. Pas besoin d'ecrire: controller\Error car le fichier se trouve déjà à l'intérieur

		$this->db = new \model\ExperienceEntityRepository;

	}
	//-------------------------------------------------
	public function redirect($location){

		header('Location: ' . $location);
	}

	//-------------------------------------------------
	public function handleRequest(){

		$xp = isset( $_GET['xp'] ) ? $_GET['xp'] : NULL;

		try{
			if( !$xp || $xp == 'list'){
				$this->listExperiences();
			}
			elseif( $xp == 'new' ){
				$this->saveExperience();
			}
			elseif( $xp == 'delete' ){
				$this->deleteExperience();
			}
			elseif( $xp == 'show'){
				$this->showExperience();
			}

			//-------------------------------------------------
			// COORECTION 
			//-------------------------------------------------
			elseif( $xp == 'update'){				
				$this->updateExperience();
			}
			else{
				$this->showError("Page not found", "Page for operation ". $xp ." was not found." );
			}
		}
		catch(Exception $e){

			$this->showError("Application error", $e->getMessage() );
		}
	}
	//-------------------------------------------------
	public function listExperiences(){

		$orderby = isset($_GET['orderby']) ? $_GET['orderby'] : NULL;

		$experiences = $this->db->selectAll($orderby);

		include 'view/experiences/experiences.php';
	}
	//-------------------------------------------------
	public function saveExperience(){

		$title = 'Add new experience';

		$entreprise ='';
		$poste ='';
		$date = '';
		$tache = '';

		if( $_POST) {

			$entreprise = isset($_POST['entreprise']) ? $_POST['entreprise'] : NULL;
			$poste = isset($_POST['poste']) ? $_POST['poste'] : NULL;
			$date = isset($_POST['date']) ? $_POST['date'] : NULL;
			$tache = isset($_POST['tache']) ? $_POST['tache'] : NULL;
			
			try{

				$res = $this->db->insert();
				$this->redirect('index.php');
				return;
			}
			catch(Exception $e){
				echo 'erreur !!';
			}
		}
		include 'view/experiences/experience-form.php';
	}

	//-------------------------------------------------
	public function deleteExperience(){

		$id = isset($_GET['id']) ? $_GET['id'] : NULL;

		if( !$id ){

			throw new Exception('Internal error.');
		}
		$res = $this->db->delete($id);

		$this->redirect('index.php');
	}

	//-------------------------------------------------
	public function showExperience(){

		$id = isset($_GET['id']) ? $_GET['id'] : NULL;

		if( ! $id ){

			throw new Exception('Internal error.');
		}
		$experience = $this->db->select($id);

		include 'view/experiences/experience.php';
	}

	//-------------------------------------------------
	// COORECTION 
	//-------------------------------------------------
	public function updateExperience(){

		$id = isset($_GET['id']) ? $_GET['id'] : NULL;
		if( ! $id ){
			throw new Exception('Internal error.');
		}
		$experience = $this->db->select($id);

		$entreprise ='';
		$poste ='';
		$date = '';
		$tache = '';

		if( $_POST) {

			$entreprise = isset($_POST['entreprise']) ? $_POST['entreprise'] : NULL;
			$poste = isset($_POST['poste']) ? $_POST['poste'] : NULL;
			$date = isset($_POST['date']) ? $_POST['date'] : NULL;
			$tache = isset($_POST['tache']) ? $_POST['tache'] : NULL;
			
			try{

				$res = $this->db->update($id);
				$this->redirect('index.php');
			}
			catch(Exception $e){
				echo 'erreur !!';
			}
		}
		include 'view/experiences/modif-experience.php';
	}
}